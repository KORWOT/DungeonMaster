namespace DungeonMaster.Battle
{
    public enum BattleEventType
    {
        Damage = 0,
        Heal = 1,
        BuffApply = 2,
        BuffRemove = 3,
        Death = 4
    }
} 